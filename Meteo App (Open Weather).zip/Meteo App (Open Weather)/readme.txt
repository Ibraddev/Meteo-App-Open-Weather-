
Fonctions de consommation de l'API OpenWeather

Pour effectuer des tests : 
 - Rendez-vous sur le site officiel de open weather
 - Créer un compte et souscrivez à l'offre gratuite
 - Coper et coller votre clé api à curl_init "{API KEY}"

Pour plus d'infos : www.openweathermap.org

