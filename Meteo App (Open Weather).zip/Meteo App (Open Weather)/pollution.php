<?php
$curl = curl_init('http://api.openweathermap.org/data/2.5/air_pollution?lat=-4.0197&lon=5.3094&appid={API KEY}');
curl_setopt_array($curl,[
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_CAINFO => 'cert_cer.cert',
	CURLOPT_TIMEOUT => 4
]);
$data = curl_exec($curl);
if ($data === false) 
{
	var_dump(curl_error($curl));
}
else
{
	if (curl_getinfo($curl, CURLINFO_HTTP_CODE)===200) #aucun probleme au niveau du serveur de l'api code 200
	{
		
		$datas= json_decode($data,true); # récuperer les résultats du json
		var_dump($datas);
		$results = [
			'monoxyde de carbone' => $datas['list'][0]['components']['co'],
			'monoxyde d\'azote' => $datas['list'][0]['components']['no'],
			'dioxyde d\'azote' => $datas['list'][0]['components']['no2'],
			'ozone' => $datas['list'][0]['components']['o3'],
			'dioxyde de soufre' => $datas['list'][0]['components']['so2'],
			'pm2_5' => $datas['list'][0]['components']['pm2_5'],
			'pm10' => $datas['list'][0]['components']['pm10'],
			'ammoniac' => $datas['list'][0]['components']['nh3']
		];
		foreach ($results as $values) {
			echo $values." | ";
		}
	}
	
}
//"components":{"monoxyde de carbone":220.3,"monoxyde d'azote":0,"dioxyde d'azote":0.15,"ozone":92.98,"dioxyde de soufre":0.29,"pm2_5":12.95,"pm10":15.4,"ammoniac ":0.17},
curl_close($curl);
?>