<?php

class OpenWeather{
	
	public $apiKey;

	public function __construct(string $apiKey)
	{
		$this->$apiKey = $apiKey;
	}

	public function getForecast(string $city):array
	{
		$curl = curl_init("api.openweathermap.org/data/2.5/forecast?q={$city}&appid={$this->$apiKey}");
		curl_setopt_array($curl,[
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_CAINFO => 'cert_cer.cer',
			CURLOPT_TIMEOUT => 4
		]);

		$datas = curl_exec($curl);
		if ($datas === false || curl_getinfo($curl, CURLINFO_HTTP_CODE)===200) 
		{
			var_dump(curl_error($curl));
			return NULL;
		}

		$results = [];
		$datas= json_decode($datas,true); # récuperer les résultats du json
		foreach ($datas['list'] as $day) 
		{
			$results = [
				'temp' => $day['main']['temp'],
				'description' => $day['weather'][0]['description'],
				'date' =>new DateTime('@'.$day['dt']) 
			];
		}
		return $results;
	}
}
?>