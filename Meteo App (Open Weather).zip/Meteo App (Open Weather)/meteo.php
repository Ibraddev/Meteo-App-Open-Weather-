<?php

function weather(string $city):string
{
	$city = htmlspecialchars($city);
	$size = strlen($city);
	if ($size < 31) 
	{
		// METEO ACTUELLE
		$curla = curl_init('http://api.openweathermap.org/data/2.5/weather?q='.$city.'&mode=json&appid={API KEY}');
		#curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); Cette methode n'est pas recommendé pour la sécurité
		curl_setopt($curla, CURLOPT_CAINFO, 'cert_cer.cer');
		curl_setopt($curla, CURLOPT_RETURNTRANSFER, true);#caché le resulat du curl 
		curl_setopt($curla, CURLOPT_TIMEOUT, 4);# delai de chargement des résulats curl
		$data = curl_exec($curla); # executer le curl
		
		if ($data === false) 
		{
			var_dump(curl_error($curla));
			$erreur = curl_error($curla);
			echo "<script type='text/javascript'> alert('".$erreur."')</script>";
		}
		else
		{
			if (curl_getinfo($curla, CURLINFO_HTTP_CODE)===200) #aucun probleme au niveau du serveur de l'api code 200
			{
				$results = [];
				$datas= json_decode($data,true); # récuperer les résultats du json
				#var_dump($datas);
				$desc = $datas['weather'][0]['description'];
				$temp = $datas['main']['temp'];
				$date = date('d/m/Y H:i:s',$datas['dt']);
				$show = $city." ".$date." Il fait ".$temp."°C ".$desc;
				#echo $show ;
			}	
		}
	}

	curl_close($curla);

	if (isset($show)) {
		return $show;
	}
	else{
		$erreur ="Saisie invalide !";
	}
}

function previsions(string $city):array
{
	// PREVISIONS 
	$curl = curl_init('http://api.openweathermap.org/data/2.5/forecast?q='.$city.'&mode=json&appid={API KEY}');
	#curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); Cette methode n'est pas recommendé pour la sécurité
	curl_setopt($curl, CURLOPT_CAINFO, 'cert_cer.cer');
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);#caché le resulat du curl 
	curl_setopt($curl, CURLOPT_TIMEOUT, 4);# delai de chargement des résulats curl
	$data = curl_exec($curl); # executer le curl
	
	if ($data === false) 
	{
		var_dump(curl_error($curl));
		$erreur = curl_error($curl);
		echo "<script type='text/javascript'> alert('".$erreur."')</script>";
	}
	else
	{
		if (curl_getinfo($curl, CURLINFO_HTTP_CODE)===200) #aucun probleme au niveau du serveur de l'api code 200
		{
			$results = [];
			$datas= json_decode($data,true); # récuperer les résultats du jso
			$i=0; 
			foreach ($datas['list'] as $day) 
			{
				?>
				
				<?php
					$i= $i + 1;
					$date = date('d/m/Y H:i:s',$day['dt']);
					$show = $date."  ".$day['weather'][0]['description']."  ".$day['main']['temp']."°C";
					array_push($results, $show);
				?>
				<?php
			}
		}
		
	}

	curl_close($curl);

	return $results;
}

function coords(string $city):array
{
	$city = htmlspecialchars($city);
	$size = strlen($city);
	if ($size < 31) 
	{
		// METEO ACTUELLE
		$curlb = curl_init('http://api.openweathermap.org/geo/1.0/direct?q='.$city.'&limit=1&appid={API KEY}');
		#curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); Cette methode n'est pas recommendé pour la sécurité
		curl_setopt($curlb, CURLOPT_CAINFO, 'cert_cer.cer');
		curl_setopt($curlb, CURLOPT_RETURNTRANSFER, true);#caché le resulat du curl 
		curl_setopt($curlb, CURLOPT_TIMEOUT, 4);# delai de chargement des résulats curl
		$data = curl_exec($curlb); # executer le curl
		
		if ($data === false) 
		{
			var_dump(curl_error($curlb));
			$erreur = curl_error($curlb);
			echo "<script type='text/javascript'> alert('".$erreur."')</script>";
		}
		else
		{
			if (curl_getinfo($curlb, CURLINFO_HTTP_CODE)===200) #aucun probleme au niveau du serveur de l'api code 200
			{
				$results = [];
				$datas= json_decode($data,true); # récuperer les résultats du json
				array_push($results, $datas[0]['lon']);
				array_push($results, $datas[0]['lat']);
				//var_dump($datas);
			}	
		}
	}

	curl_close($curlb);

	return $results;
}

function pollution(string $city)
{
	$city = htmlspecialchars($city);
	$size = strlen($city);
	if ($size < 31) 
	{

		$lon = coords($city)[0];
		$lat = coords($city)[1];
		$curlc = curl_init('http://api.openweathermap.org/data/2.5/air_pollution?lat='.$lat.'&lon='.$lon.'&appid={API KEY}');
		#curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); Cette methode n'est pas recommendé pour la sécurité
		curl_setopt($curlc, CURLOPT_CAINFO, 'cert_cer.cer');
		curl_setopt($curlc, CURLOPT_RETURNTRANSFER, true);#caché le resulat du curl 
		curl_setopt($curlc, CURLOPT_TIMEOUT, 4);# delai de chargement des résulats curl
		$data = curl_exec($curlc); # executer le curl
		
		if ($data === false) 
		{
			var_dump(curl_error($curlc));
			$erreur = curl_error($curlc);
			echo "<script type='text/javascript'> alert('".$erreur."')</script>";
		}
		else
		{
			if (curl_getinfo($curlc, CURLINFO_HTTP_CODE)===200) #aucun probleme au niveau du serveur de l'api code 200
			{
				$results = [];
				$datas= json_decode($data,true); # récuperer les résultats du json
				//var_dump($datas);
				$results = [
					'monoxyde de carbone' => $datas['list'][0]['components']['co'],
					'monoxyde d\'azote' => $datas['list'][0]['components']['no'],
					'dioxyde d\'azote' => $datas['list'][0]['components']['no2'],
					'ozone' => $datas['list'][0]['components']['o3'],
					'dioxyde de soufre' => $datas['list'][0]['components']['so2'],
					'pm2_5' => $datas['list'][0]['components']['pm2_5'],
					'pm10' => $datas['list'][0]['components']['pm10'],
					'ammoniac' => $datas['list'][0]['components']['nh3']
				];
				foreach ($results as $values) {
					echo $values." | ";
				}
			}	
		}
	}

	curl_close($curlc);
}

?>