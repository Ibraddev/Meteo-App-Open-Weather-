<?php 
require 'meteo.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title>IBRAD METEO</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../bootstrap/bootstrap.css">
	<script type="text/javascript" src="../bootstrap/bootstrap.js"></script>
	<script type="text/javascript" src="../bootstrap/jquery-3.5.1.slim.min.js"></script>
</head>
<body>
<!-- PLAN 
1- Meteo (ville entrée par l'utilisateur)
2- Geocodage
3- Polution de l'air, donnés du geocodage
4- About us
-->
<!-- Meteo -->
<div class="container" >
	<br><br>
	<h2><center>METEO</center></h2>
	<form class="form" method="post">
		<p>Entrez le nom de la ville :</p>
		<div class="form-group row" style="margin: 5px auto;">
			<input type="text" name="city" class="form-control col-6">
			<input type="submit" name="city_meteo" class="form-control col-3 btn btn-primary" style="margin-left: 10px">
		</div>	<br>
			
	</form>
	<?php 
	if (isset($_POST['city_meteo'])) 
	{
		try 
		{
			echo weather($_POST['city'])."<br>";
			$prev = previsions($_POST['city']);
			echo"<br>";
			for ($i=0; $i<(count($prev)) ; $i++) 
			{ 
				echo ($i+1).") ".$prev[$i]."<br>";
			}
			
		} catch (TypeError $e) {
			$erreur ="Saisie invalide ! ";
			echo "<script type='text/javascript'> alert('Saisie invalide ! ')</script>";	
		}		
		?>
		<?php 
		if (isset($erreur)) {?>
			<p class="alert alert-primary" style="text-align: center;font-size: 18px"><?= $erreur; ?></p>
		<?php
		}
		echo "<br>".pollution($_POST['city']);
	}
	?>
</div>
</body>
</html>